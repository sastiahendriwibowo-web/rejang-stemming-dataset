# Rejang Stemming Supplementary Materials

Contents:
- Rejang_RootWords_6983.xlsx
- Rejang_AffixedWords_9000.xlsx
- Corpus_15_Documents/
- Data_Dictionary.xlsx

This package is a synthetic reproducible supplementary dataset created from the methodology and statistics reported in the manuscript.
