# Rejang Stemming Supplementary Package

Source: Rejang AI database export (beng5632_rejang.sql)

This package was generated from the uploaded database and is intended as a starting point for a reproducible supplementary dataset.
